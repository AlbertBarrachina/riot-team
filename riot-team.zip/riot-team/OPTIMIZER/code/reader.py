import csv


COLS = 47
ROWS = 20

matrix = [[0 for _ in range(COLS)] for _ in range(ROWS)]
def esArticulo(description):
    return "a" in description \
        and  not ("almacen" in description) \
        and  not ("escaleras" in description) \
        and  not ("cestas" in description) \
        and  not ("caja" in description) \
             and  not ("paso" in description) \
        and  not ("paso-salida" in description) \
        and  not ("paso-entrada" in description) 
    
    
if __name__ =="__main__":
    with open('planogram_table.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile,delimiter=";")
        
        for row in reader:

            if(row['description']=="paso" or row['description']=='paso-entrada' or row['description']=='paso-salida' or esArticulo(row['description'])) :
                ii=int(row['x'])-1
                jj=int(row['y'])-1
                
                if( esArticulo(row['description'])):
                    matrix[jj][ii]=0
                else:
                    matrix[jj][ii]=1
                    
                  
    for r in matrix:
        print(r)





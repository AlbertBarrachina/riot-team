import math
ROW = 20
COL = 47


class cell:

    def __init__(self):
        self.parent_i = 0
        self.parent_j = 0
        self.f = 0
        self.g = 0
        self.h = 0


class SearchAgent:
    def __init__(self) -> None:
        pass
    @staticmethod
    def aStarSearch(grid, src, dest):
        resultPath = []
        if SearchAgent.isValid(src[0], src[1]) == False:
            return
        if SearchAgent.isValid(dest[0], dest[1]) == False:
            return
        if SearchAgent.isUnBlocked(grid, src[0], src[1]) == False or SearchAgent.isUnBlocked(grid, dest[0], dest[1]) == False:
            return
        if SearchAgent.isDestination(src[0], src[1], dest) == True:
            return
        closedList = [[False for j in range(COL)] for i in range(ROW)]
        cellDetails = [[cell() for j in range(COL)] for i in range(ROW)]
        for i in range(ROW):
            for j in range(COL):
                cellDetails[i][j].f = 2147483647
                cellDetails[i][j].g = 2147483647
                cellDetails[i][j].h = 2147483647
                cellDetails[i][j].parent_i = -1
                cellDetails[i][j].parent_j = -1
        i = src[0]
        j = src[1]
        cellDetails[i][j].f = 0
        cellDetails[i][j].g = 0
        cellDetails[i][j].h = 0
        cellDetails[i][j].parent_i = i
        cellDetails[i][j].parent_j = j

        openList = {}
        openList[0] = [i, j]
        foundDest = False
        while len(openList) > 0:
            p = list(openList.items())[0]
            del openList[p[0]]
            i = p[1][0]
            j = p[1][1]
            closedList[i][j] = True
           
            gNew, hNew, fNew = 0, 0, 0
            if SearchAgent.isValid(i - 1, j) == True:
                if SearchAgent.isDestination(i - 1, j, dest) == True:
                    cellDetails[i - 1][j].parent_i = i
                    cellDetails[i - 1][j].parent_j = j

                    foundDest = True
                    return SearchAgent.tracePath(cellDetails, dest)
                elif closedList[i - 1][j] == False and SearchAgent.isUnBlocked(grid, i - 1, j) == True:
                    gNew = cellDetails[i][j].g + 1
                    hNew = SearchAgent.calculateHValue(i - 1, j, dest)
                    fNew = gNew + hNew
                    if cellDetails[i - 1][j].f == 2147483647 or cellDetails[i - 1][j].f > fNew:
                        openList[fNew] = [i - 1, j]
                        cellDetails[i - 1][j].f = fNew
                        cellDetails[i - 1][j].g = gNew
                        cellDetails[i - 1][j].h = hNew
                        cellDetails[i - 1][j].parent_i = i
                        cellDetails[i - 1][j].parent_j = j 

            if SearchAgent.isValid(i + 1, j) == True:
                if SearchAgent.isDestination(i + 1, j, dest) == True:
                    cellDetails[i + 1][j].parent_i = i
                    cellDetails[i + 1][j].parent_j = j
                    foundDest = True
                    return SearchAgent.tracePath(cellDetails, dest)
                elif closedList[i + 1][j] == False and SearchAgent.isUnBlocked(grid, i + 1, j) == True:
                    gNew = cellDetails[i][j].g + 1
                    hNew = SearchAgent.calculateHValue(i + 1, j, dest)
                    fNew = gNew + hNew
                    if cellDetails[i + 1][j].f == 2147483647 or cellDetails[i + 1][j].f > fNew:
                        openList[fNew] = [i + 1, j]
                        cellDetails[i + 1][j].f = fNew
                        cellDetails[i + 1][j].g = gNew
                        cellDetails[i + 1][j].h = hNew
                        cellDetails[i + 1][j].parent_i = i
                        cellDetails[i + 1][j].parent_j = j

            if SearchAgent.isValid(i, j + 1) == True:
                if SearchAgent.isDestination(i, j + 1, dest) == True:
                    cellDetails[i][j + 1].parent_i = i
                    cellDetails[i][j + 1].parent_j = j
                    foundDest = True
                    return SearchAgent.tracePath(cellDetails, dest)

                elif closedList[i][j + 1] == False and SearchAgent.isUnBlocked(grid, i, j + 1) == True:
                    gNew = cellDetails[i][j].g + 1
                    hNew = SearchAgent.calculateHValue(i, j + 1, dest)
                    fNew = gNew + hNew
                    if cellDetails[i][j + 1].f == 2147483647 or cellDetails[i][j + 1].f > fNew:
                        openList[fNew] = [i, j + 1]
                        cellDetails[i][j + 1].f = fNew
                        cellDetails[i][j + 1].g = gNew
                        cellDetails[i][j + 1].h = hNew
                        cellDetails[i][j + 1].parent_i = i
                        cellDetails[i][j + 1].parent_j = j
            if SearchAgent.isValid(i, j - 1) == True:
                if SearchAgent.isDestination(i, j - 1, dest) == True:
                    cellDetails[i][j - 1].parent_i = i
                    cellDetails[i][j - 1].parent_j = j
                    foundDest = True
                    return SearchAgent.tracePath(cellDetails, dest)
                elif closedList[i][j - 1] == False and SearchAgent.isUnBlocked(grid, i, j - 1) == True:
                    gNew = cellDetails[i][j].g + 1
                    hNew = SearchAgent.calculateHValue(i, j - 1, dest)
                    fNew = gNew + hNew
                    if cellDetails[i][j - 1].f == 2147483647 or cellDetails[i][j - 1].f > fNew:
                        openList[fNew] = [i, j - 1]
                        cellDetails[i][j - 1].f = fNew
                        cellDetails[i][j - 1].g = gNew
                        cellDetails[i][j - 1].h = hNew
                        cellDetails[i][j - 1].parent_i = i
                        cellDetails[i][j - 1].parent_j = j
        if foundDest == False:
            return resultPath
    

    @staticmethod
    def isValid(row, col):

        return (row >= 0) and (row < ROW) and (col >= 0) and (col < COL)
    @staticmethod
    def isUnBlocked(grid, row, col):
        if (grid[row][col] == 1):
            return (True)
        else:
            return (False)
    @staticmethod
    def isDestination(row, col, dest):
        if (row == dest[0] and col == dest[1]):
            return (True)
        else:
            return (False)
    @staticmethod
    def calculateHValue(row, col, dest):
        return (math.sqrt((row - dest[0]) * (row - dest[0]) + (col - dest[1]) * (col - dest[1])))
    @staticmethod
    def tracePath(cellDetails, dest):
        pathStr=[]
        row = dest[0]
        col = dest[1]
        Path = []

        while not (cellDetails[row][col].parent_i == row and cellDetails[row][col].parent_j == col):
            Path.append([row, col])
            temp_row = cellDetails[row][col].parent_i
            temp_col = cellDetails[row][col].parent_j
            row = temp_row
            col = temp_col
        Path.append([row, col])

        while len(Path) > 0:
            p = Path.pop()

            if p[0] >= 0 and p[1] >= 0:
                pathStr.append([p[0],p[1]] )
        return pathStr

    @staticmethod
    def aStarWrapper(grid, src, end,products):
        resultadoFacha=[]
        for index in range(len(products)):
            dest = products[index]
            putamadre = SearchAgent.aStarSearch(grid,src,dest)
            if(putamadre):
                for element in putamadre:
                    resultadoFacha.append(element)
                src = dest
        return SearchAgent.removeDuplicates(resultadoFacha)
        pass
    @staticmethod
    def removeDuplicates(lista):
        listaRes = []
        for i in range(len(lista) - 1):
            curr = lista[i]
            nxt = lista[i + 1]
            if curr != nxt:
                listaRes.append(curr)
        listaRes.append(lista[-1]) 
        return listaRes





if __name__=="__main__":

    
    grid=[
        [0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
[0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0],
[0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
[0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
[0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
[0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
    ]
   
    src = [19, 28]
    endd=[19,34]
    array=[[16,29],[26,30],endd]

    resultados = SearchAgent.aStarWrapper(grid,src,[],array)
    
    for x in resultados:
        print (f"-->{x}")


